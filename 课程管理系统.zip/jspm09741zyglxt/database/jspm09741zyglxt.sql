/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : jspm09741zyglxt

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2022-03-11 16:09:55
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `admins`
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '帐号',
  `pwd` varchar(50) NOT NULL DEFAULT '' COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员';

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES ('1', 'admin', 'admin');

-- ----------------------------
-- Table structure for `banjixinxi`
-- ----------------------------
DROP TABLE IF EXISTS `banjixinxi`;
CREATE TABLE `banjixinxi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `banji` varchar(50) NOT NULL DEFAULT '' COMMENT '班级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='班级信息';

-- ----------------------------
-- Records of banjixinxi
-- ----------------------------
INSERT INTO `banjixinxi` VALUES ('1', '一班');
INSERT INTO `banjixinxi` VALUES ('2', '二班');
INSERT INTO `banjixinxi` VALUES ('3', '三班');
INSERT INTO `banjixinxi` VALUES ('4', '四班');
INSERT INTO `banjixinxi` VALUES ('5', '五班');

-- ----------------------------
-- Table structure for `gonggaoxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `gonggaoxinxi`;
CREATE TABLE `gonggaoxinxi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gonggaobianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '公告编号',
  `gonggaobiaoti` varchar(50) NOT NULL DEFAULT '' COMMENT '公告标题',
  `gonggaoneirong` text NOT NULL COMMENT '公告内容',
  `faburen` varchar(64) NOT NULL DEFAULT '' COMMENT '发布人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='公告信息';

-- ----------------------------
-- Records of gonggaoxinxi
-- ----------------------------
INSERT INTO `gonggaoxinxi` VALUES ('1', '01051615261234', '通知XX实验室断电', '测试测试测试', 'admin');

-- ----------------------------
-- Table structure for `ketangxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `ketangxinxi`;
CREATE TABLE `ketangxinxi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ketangbianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '课堂编号',
  `ketangmingcheng` varchar(255) NOT NULL DEFAULT '' COMMENT '课堂名称',
  `fabulaoshi` varchar(64) NOT NULL DEFAULT '' COMMENT '发布老师',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='课堂信息';

-- ----------------------------
-- Records of ketangxinxi
-- ----------------------------
INSERT INTO `ketangxinxi` VALUES ('3', '01051616071690', '英语课堂', '100');
INSERT INTO `ketangxinxi` VALUES ('4', '01051616092316', '数学课堂', '100');

-- ----------------------------
-- Table structure for `laoshi`
-- ----------------------------
DROP TABLE IF EXISTS `laoshi`;
CREATE TABLE `laoshi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gonghao` varchar(50) NOT NULL DEFAULT '' COMMENT '工号',
  `mima` varchar(50) NOT NULL DEFAULT '' COMMENT '密码',
  `zhicheng` varchar(50) NOT NULL DEFAULT '' COMMENT '职称',
  `laoshixingming` varchar(50) NOT NULL DEFAULT '' COMMENT '老师姓名',
  `xingbie` varchar(10) NOT NULL COMMENT '性别',
  `lianxidianhua` varchar(50) NOT NULL DEFAULT '' COMMENT '联系电话',
  `youxiang` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='老师';

-- ----------------------------
-- Records of laoshi
-- ----------------------------
INSERT INTO `laoshi` VALUES ('4', '100', '100', 'XX职称', '李建国', '男', '13666666666', '123@qq.com');

-- ----------------------------
-- Table structure for `xiaozuxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `xiaozuxinxi`;
CREATE TABLE `xiaozuxinxi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `xiaozubianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '小组编号',
  `xiaozumingcheng` varchar(255) NOT NULL DEFAULT '' COMMENT '小组名称',
  `xiaozurenyuan` text NOT NULL COMMENT '小组人员',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='小组信息';

-- ----------------------------
-- Records of xiaozuxinxi
-- ----------------------------
INSERT INTO `xiaozuxinxi` VALUES ('4', '01051613481724', '第一小组', '11,10,9');
INSERT INTO `xiaozuxinxi` VALUES ('5', '01051613519256', '第二小组', '13,12');
INSERT INTO `xiaozuxinxi` VALUES ('6', '01051613538176', '第三小组', '15,14');

-- ----------------------------
-- Table structure for `xuesheng`
-- ----------------------------
DROP TABLE IF EXISTS `xuesheng`;
CREATE TABLE `xuesheng` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `xuehao` varchar(50) NOT NULL DEFAULT '' COMMENT '学号',
  `mima` varchar(50) NOT NULL DEFAULT '' COMMENT '密码',
  `banji` int(50) NOT NULL COMMENT '班级',
  `suoshuxiaozu` varchar(50) NOT NULL COMMENT '所属小组',
  `xueshengxingming` varchar(50) NOT NULL DEFAULT '' COMMENT '学生姓名',
  `xingbie` varchar(10) NOT NULL COMMENT '性别',
  `lianxidianhua` varchar(50) NOT NULL DEFAULT '' COMMENT '联系电话',
  `youxiang` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='学生';

-- ----------------------------
-- Records of xuesheng
-- ----------------------------
INSERT INTO `xuesheng` VALUES ('9', '111', '111', '1', '01051613481724', '小明', '男', '13666666666', '123456@qq.com');
INSERT INTO `xuesheng` VALUES ('10', '222', '222', '1', '01051613481724', '小红', '女', '13666666666', '123456@qq.com');
INSERT INTO `xuesheng` VALUES ('11', '333', '333', '1', '01051613481724', '小白', '女', '13666666666', '123456@qq.com');
INSERT INTO `xuesheng` VALUES ('12', '444', '444', '2', '01051613519256', '小黑', '男', '13666666666', '123456@qq.com');
INSERT INTO `xuesheng` VALUES ('13', '555', '555', '1', '01051613519256', '小蓝', '女', '13666666666', '123456@qq.com');
INSERT INTO `xuesheng` VALUES ('14', '666', '666', '2', '01051613519256', '小粉', '女', '13666666666', '123456@qq.com');
INSERT INTO `xuesheng` VALUES ('15', '777', '777', '2', '01051613538176', '小青', '女', '13666666666', '123456@qq.com');

-- ----------------------------
-- Table structure for `zuoyecuijiao`
-- ----------------------------
DROP TABLE IF EXISTS `zuoyecuijiao`;
CREATE TABLE `zuoyecuijiao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zuoyexinxiid` int(10) unsigned NOT NULL COMMENT '作业信息id',
  `zuoyebianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '作业编号',
  `zuoyebiaoti` varchar(50) NOT NULL DEFAULT '' COMMENT '作业标题',
  `fenpeixiaozu` varchar(50) NOT NULL COMMENT '分配小组',
  `xinxineirong` text NOT NULL COMMENT '信息内容',
  `cuijiaoren` varchar(64) NOT NULL DEFAULT '' COMMENT '催缴人',
  PRIMARY KEY (`id`),
  KEY `zuoyecuijiao_zuoyexinxiid_index` (`zuoyexinxiid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='作业催交';

-- ----------------------------
-- Records of zuoyecuijiao
-- ----------------------------
INSERT INTO `zuoyecuijiao` VALUES ('1', '2', '01051616191905', '线性代数', '01051613481724', '快点哦', '100');

-- ----------------------------
-- Table structure for `zuoyejianyue`
-- ----------------------------
DROP TABLE IF EXISTS `zuoyejianyue`;
CREATE TABLE `zuoyejianyue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zuoyetijiaoid` int(10) unsigned NOT NULL COMMENT '作业提交id',
  `zuoyebianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '作业编号',
  `zuoyebiaoti` varchar(50) NOT NULL DEFAULT '' COMMENT '作业标题',
  `tijiaoxuesheng` varchar(64) NOT NULL DEFAULT '' COMMENT '提交学生',
  `tijiaoxiaozu` varchar(50) NOT NULL COMMENT '提交小组',
  `piyuezhuangtai` varchar(50) NOT NULL COMMENT '批阅状态',
  `fenshu` int(11) NOT NULL DEFAULT '0' COMMENT '分数',
  `piyuejianyi` text NOT NULL COMMENT '批阅建议',
  `piyueren` varchar(64) NOT NULL DEFAULT '' COMMENT '批阅人',
  PRIMARY KEY (`id`),
  KEY `zuoyejianyue_zuoyetijiaoid_index` (`zuoyetijiaoid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='作业检阅';

-- ----------------------------
-- Records of zuoyejianyue
-- ----------------------------
INSERT INTO `zuoyejianyue` VALUES ('1', '2', '01051616191905', '线性代数', '111', '01051613481724', '优秀', '99', '继续加油', '100');

-- ----------------------------
-- Table structure for `zuoyetijiao`
-- ----------------------------
DROP TABLE IF EXISTS `zuoyetijiao`;
CREATE TABLE `zuoyetijiao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zuoyexinxiid` int(10) unsigned NOT NULL COMMENT '作业信息id',
  `zuoyebianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '作业编号',
  `zuoyebiaoti` varchar(50) NOT NULL DEFAULT '' COMMENT '作业标题',
  `buzhilaoshi` varchar(64) NOT NULL DEFAULT '' COMMENT '布置老师',
  `zuoyeneirong` text NOT NULL COMMENT '作业内容',
  `fujian` varchar(255) NOT NULL DEFAULT '' COMMENT '附件',
  `zhuangtai` varchar(50) NOT NULL COMMENT '状态',
  `tijiaoxiaozu` varchar(50) NOT NULL COMMENT '提交小组',
  `tijiaoxuesheng` varchar(64) NOT NULL DEFAULT '' COMMENT '提交学生',
  PRIMARY KEY (`id`),
  KEY `zuoyetijiao_zuoyexinxiid_index` (`zuoyexinxiid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='作业提交';

-- ----------------------------
-- Records of zuoyetijiao
-- ----------------------------
INSERT INTO `zuoyetijiao` VALUES ('2', '2', '01051616191905', '线性代数', '100', '测试测试测试', 'upload/1641370713589.xls', '优秀', '01051613481724', '111');

-- ----------------------------
-- Table structure for `zuoyexinxi`
-- ----------------------------
DROP TABLE IF EXISTS `zuoyexinxi`;
CREATE TABLE `zuoyexinxi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zuoyebianhao` varchar(50) NOT NULL DEFAULT '' COMMENT '作业编号',
  `suoshukecheng` int(10) unsigned NOT NULL COMMENT '所属课程',
  `zuoyebiaoti` varchar(50) NOT NULL DEFAULT '' COMMENT '作业标题',
  `zuoyeneirong` text NOT NULL COMMENT '作业内容',
  `banji` int(11) NOT NULL,
  `yaoqiushixian` varchar(25) NOT NULL COMMENT '要求时限',
  `fujian` varchar(255) NOT NULL DEFAULT '' COMMENT '附件',
  `fenpeixiaozu` varchar(50) NOT NULL COMMENT '分配小组',
  `buzhilaoshi` varchar(64) NOT NULL DEFAULT '' COMMENT '布置老师',
  PRIMARY KEY (`id`),
  KEY `zuoyexinxi_suoshukecheng_index` (`suoshukecheng`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='作业信息';

-- ----------------------------
-- Records of zuoyexinxi
-- ----------------------------
INSERT INTO `zuoyexinxi` VALUES ('2', '01051616191905', '4', '线性代数', '讲解线性代数的运用', '2', '2022-01-05 16:16:35', 'upload/1641370610963.xls', '01051613481724', '100');
